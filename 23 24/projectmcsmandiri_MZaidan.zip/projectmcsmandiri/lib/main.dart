import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Menu Makanan',
      theme: ThemeData(
        primarySwatch: Colors.green
      ),
      home: FoodList(),
    );
  }
}

class FoodList extends StatefulWidget {
  @override
  _FoodListState createState() => _FoodListState();
}

class _FoodListState extends State<FoodList> {
  final List<Food> foods = [
    Food(name: "Nasi Goreng", imageUrl: "https://cdn1-production-images-kly.akamaized.net/DNNlr3RpoiI9ibopabhBLZBwoeU=/0x0:2048x1154/1200x675/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3150685/original/078025300_1591931057-nasi_goreng_daging.jpg", price: 15000),
    Food(name: "Sate Ayam", imageUrl: "https://www.sasa.co.id/medias/page_medias/cara_bikin_sate_ayam_empuk.jpg", price: 20000),
    Food(name: "Nasi Bebek", imageUrl: "https://asset.kompas.com/crops/F-VKSmk4OsKGGuDhxHxQoHvg8BU=/0x726:2448x2358/750x500/data/photo/2019/09/02/5d6ce7a08a88f.jpg", price: 25000),
    Food(name: "Ayam Geprek", imageUrl: "https://www.masakapahariini.com/wp-content/uploads/2023/03/shutterstock_1949306203-500x300.jpg", price: 25000),
    Food(name: "Martabak Manis", imageUrl: "https://photo.kontan.co.id/photo/2017/05/02/993715042p.jpg", price: 40000),
    Food(name: "Sate Padang", imageUrl: "https://static.promediateknologi.id/crop/7x253:1079x988/750x500/webp/photo/2021/11/11/743627285.jpg", price: 20000),
    Food(name: "Dimsum", imageUrl: "https://awsimages.detik.net.id/community/media/visual/2022/01/24/resep-siomay-ayam_43.jpeg?w=600&q=90", price: 18000),
    // untuk menambahkan url dan gambar makanan
  ];

  List<Food> cart = [];

  void addToCart(Food food) {
    setState(() {
      cart.add(food);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Makanan'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Cart(cart: cart)),
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: foods.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: Image.network(foods[index].imageUrl),
              title: Text(foods[index].name),
              subtitle: Text('Rp${foods[index].price}'),
              trailing: IconButton(
                icon: Icon(Icons.add_shopping_cart),
                onPressed: () {
                  addToCart(foods[index]);
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

class Cart extends StatefulWidget {
  final List<Food> cart;

  Cart({Key? key, required this.cart}) : super(key: key);

  @override
  _CartState createState() => _CartState();
}

class _CartState extends State<Cart> {
  void removeFromCart(Food food) {
    setState(() {
      widget.cart.remove(food);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Keranjang Belanja'),
      ),
      body: ListView.builder(
        itemCount: widget.cart.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              leading: Image.network(widget.cart[index].imageUrl),
              title: Text(widget.cart[index].name),
              subtitle: Text('Rp${widget.cart[index].price}'),
              trailing: IconButton(
                icon: Icon(Icons.remove_shopping_cart),
                onPressed: () {
                  removeFromCart(widget.cart[index]);
                },
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: BottomAppBar(
        child: ElevatedButton(
          child: Text('Checkout'),
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Checkout(cart: widget.cart)),
            );

          },
        ),
      ),
    );
  }
}
class Checkout extends StatelessWidget {
  final List<Food> cart;

  Checkout({Key? key, required this.cart}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int total = 0;
    cart.forEach((item) {
      total += item.price;
    });

    return Scaffold(
      appBar: AppBar(
        title: Text('Checkout'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              itemCount: cart.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(cart[index].name),
                  subtitle: Text('Rp${cart[index].price}'),
                );
              },
            ),
          ),
          Text('Total: Rp$total', style: TextStyle(fontSize: 24)),
          ElevatedButton(
            onPressed: () {
              // Implement your checkout functionality here
            },
            child: Text('Pesan Sekarang'),
          ),
        ],
      ),
    );
  }
}

class Food {
  final String name;
  final String imageUrl;
  final int price;

  Food({required this.name, required this.imageUrl, required this.price});
}
