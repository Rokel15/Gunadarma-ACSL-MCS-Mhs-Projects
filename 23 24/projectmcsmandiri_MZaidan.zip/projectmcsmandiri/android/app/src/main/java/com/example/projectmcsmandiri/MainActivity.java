package com.example.projectmcsmandiri;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
