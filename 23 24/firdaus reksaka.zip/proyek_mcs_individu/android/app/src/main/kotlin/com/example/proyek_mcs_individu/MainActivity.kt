package com.example.proyek_mcs_individu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
