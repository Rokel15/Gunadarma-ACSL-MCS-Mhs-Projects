package com.example.projetcs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
