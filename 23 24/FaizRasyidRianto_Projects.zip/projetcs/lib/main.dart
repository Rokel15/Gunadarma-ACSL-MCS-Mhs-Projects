import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';


void main() {
  runApp(MaterialApp(
    title: 'Calendar',
    debugShowCheckedModeBanner: false,
    home: MyApp(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  DateTime today = DateTime.now();

  void _today(DateTime day, DateTime focusedDay){
    setState(() {
      today = day;
    });
  }

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Caledar',)
      ),
      body: content(),
    );
  }

  Widget content() {
    return Column(
      children: [
        Text("Hari Yang Di Pilih " + today.toString().split(" ")[0]),
        Container(
          child: TableCalendar(
              headerStyle: HeaderStyle(titleCentered: true),
              availableGestures: AvailableGestures.all,
              startingDayOfWeek: StartingDayOfWeek.monday,
              focusedDay: today,
              firstDay: DateTime.utc(2024, 1, 1),
              lastDay: DateTime.utc(2050, 12, 31),
              onDaySelected: _today,
              selectedDayPredicate: (day) => isSameDay(day, today),
          ),
        ),
      ],
    );
  }
}
