package com.example.tugas_akhirr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
