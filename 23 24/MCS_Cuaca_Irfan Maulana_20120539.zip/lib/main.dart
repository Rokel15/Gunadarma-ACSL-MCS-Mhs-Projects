import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Weather App',
      home: WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final apiKey = 'e373bd7eb0cbd834217f90ac580529b0';
  String selectedCity = 'Jakarta';
  final List<String> cities = [
    'Jakarta',
    'Depok',
    'Bekasi',
    'Tangerang',
    'Bogor',
    'Bandung',
    'Surabaya',
    'Medan',
    'Semarang',
    'Makassar',
    'Palembang',
    'Tokyo',
    'Shanghai',
    'London',
    'New York',
    'Moscow',
    'Paris',
    'Sao Paulo',
    'Cape Town',
    'Sydney',
    'Los Angeles',
    'Istanbul'
  ];

  Future<Map<String, dynamic>> getWeather() async {
    final response = await http.get(Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?q=$selectedCity&appid=$apiKey'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load weather');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CUAxA by Irfun'),
        centerTitle: true,
      ),
      body: Center(
        child: Container(
          width: 300,
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.lightBlueAccent,
                spreadRadius: 100,
                blurRadius: 500,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Weather in',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              DropdownButton<String>(
                value: selectedCity,
                isExpanded: true,
                style: TextStyle(
                  fontSize: 25,
                  color: Colors.grey,
                ),
                items: cities.map<DropdownMenuItem<String>>((String city) {
                  return DropdownMenuItem<String>(
                    value: city,
                    child: Center(
                      child: Text(
                        city,
                        style: TextStyle(
                          fontSize: 25,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    selectedCity = value!;
                  });
                },
              ),
              SizedBox(height: 25),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.white,
                ),
                child: FutureBuilder(
                  future: getWeather(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError) {
                      return Center(child: Text('Error: ${snapshot.error}'));
                    } else {
                      final weatherData = snapshot.data as Map<String, dynamic>;
                      final temperature = (weatherData['main']['temp'] - 273.15)
                          .toStringAsFixed(2);
                      final humidity =
                          weatherData['main']['humidity'].toString();
                      final windSpeed = weatherData['wind']['speed'].toString();
                      final weatherDescription =
                          weatherData['weather'][0]['description'];

                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          buildWeatherInfo('Temperature', '$temperature °C'),
                          buildWeatherInfo('Humidity', '$humidity%'),
                          buildWeatherInfo('Wind Speed', '$windSpeed m/s'),
                          buildWeatherInfo('Weather', weatherDescription),
                        ],
                      );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildWeatherInfo(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title + ':',
            style: TextStyle(fontSize: 20, color: Colors.black),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.green[400],
            ),
          ),
        ],
      ),
    );
  }
}
