package com.example.projectawal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
