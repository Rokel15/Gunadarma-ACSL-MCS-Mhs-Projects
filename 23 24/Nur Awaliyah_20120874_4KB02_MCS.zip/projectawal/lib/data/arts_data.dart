import 'package:projectawal/models/art.dart';

List<Art> arts = [
  Art(
      urlImage:
      "https://1.bp.blogspot.com/-qXGL90V9txw/XUpo3qbURVI/AAAAAAAAJC0/rShqgV2UvtgPQ3qv6i11Fc9vwzlt2T_xwCLcBGAs/s1600/Aliran_Seni_Lukis_Romantisme.jpg",
      name: "Lukisan Romantisme",
      desc:
      '''Lukisan Romantisme merupakan aliran seni lukis yang berusaha menampilkan suatu lukisan dengan indah dan fantastik. Aliran Romantisme melukiskan tentang suatu hal yang bersifat romance, seperti sebuah tragedi, sejarah maupun pemandangan alam dan menampilkan suatu lukisan dengan fantastik. Romantisisme berasal dari kata Perancis, roman (cerita), dan memang dalam gaya Romantisisme juga mencerminkan adanya pengaruh sastra roman Perancis. Terutama dalam melukiskan cerita-cerita tragedi yang dasyat, kejadian dramatis yang mencekam. Romantisisme tetap merupakan gerakan seni yang lari dari kenyataan hidup, menggarap dunia yang ideal dan misterius dengan menggunakan teknik-teknik akademisme yang rasional.'''),
  Art(
      urlImage:
      "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/182/2023/10/11/naturalisJPG-609814806.jpg",
      name: "Lukisan Naturalisme",
      desc:
      '''Lukisan Naturalisme adalah aliran seni lukis yang menampilkan subjeknya semirip mungkin dengan yang terlihat di alam nyata. Detailnya realistis dan sangat akurat, serta berusaha merepresentasikan kenyataan tanpa penambahan, seminimal mungkin distorsi dan interpretasi, serta menghindari elemen-elemen fiksional dan spekulatif.'''),
  Art(
      urlImage:
      "https://4.bp.blogspot.com/-2lL0ztb2kOo/Wr7OL7FlGEI/AAAAAAAAAcs/qd6xeKuBaKU2diGtURy3_e7mYmHafx8wgCLcBGAs/s1600/lukisan%2Brealisme.jpg",
      name: "Lukisan Realisme",
      desc:
      '''Lukisan Realisme adalah aliran seni rupa yang menceritakan kehidupan sehari-hari di dunia nyata tanpa dibuat-buat. Tema-tema lukisan realisme biasanya menggambarkan cerita kehidupan pada zamannya masing-masing. Realisme berusaha mengungkap realitas kehidupan serealistis mungkin, yaitu bagaimana rupa alam beserta isinya yang bisa dilihat dengan mata ke dalam suatu lukisan. Pelukis realisme selalu berusaha menunjukkan kehidupan sehari-hari dari karakter, bagaimana suasananya, dilema, dan objek. Realisme banyak mengabaikan subjek-subjek yang tampil dalam ruang yang terlalu luas dan menghindari bentuk-bentuk klasik lainnya yang lebih populer saat itu. Pelukis realisme akan selalu mengamati dan meniru bentuk-bentuk di alam secara akurat.'''),
  Art(
      urlImage:
      "https://asset.kompas.com/crops/CmKXF3kZFLqnW3CZEyvrUyusxf8=/0x65:715x542/780x390/data/photo/2023/10/11/6526854e94659.jpeg",
      name: "Lukisan Dadalisme",
      desc:
      '''Lukisan Dadaisme adalah aliran yang tidak ingin membuat suatu karya indah secara fisik, namun bermuatan kritik tajam, pesan perdamaian atau pesan sosial lain dengan cara membuat sindiran tidak langsung, hingga ke ungkapan langsung yang provokatif terhadap kaum-kaum yang dianggap memberikan pengaruh negatif pada kelangsungan hidup manusia. Aliran dadaisme menggunakan tema-tema yang bertentangan dengan seni tinggi Eropa yang dianggap sebagai aliran mainstream pada masa itu. Para Seniman Dada menggunakan tema-tema yang mengerikan,  mistis dan menyeramkan, namun justru terkadang kekanak-kanakan atau naif, atau tema apapun yang tidak menunjukkan keindahan estetis yang telah mapan sebelumnya. '''),
  Art(
      urlImage:
      "https://www.goodnewsfromindonesia.id/wp-content/uploads/images/source/ahda_fariha/roby/01abb35d-4183-4ebc-9a2f-3cbcfafe0131.jpg",
      name: "Lukisan Surealisme",
      desc:
      '''Lukisan Surealisme adalah aliran yang menggambarkan kontradiksi antara konsep mimpi dan kenyataan dengan gambar yang menunjukkan objek nyata dalam situasi yang tidak mungkin seperti mimpi dan alam bawah sadar manusia. Surealisme pada dasarnya menggunakan pendekatan teori psikologi Freud untuk menyampaikan maksud atau mengeksplorasi alam bawah sadar, yakni citra mimpi manusia sebagai ekspresi keinginan manusia tersebut. Ide pada karya Surealisme sebagai seni ini selalu memiliki elemen menakjubkan di setiap gambarnya. Citra Surealisme tidak pernah terjadi dalam pikiran manusia. Selain menempatkan benda-benda aneh, Surealisme juga menambahkan pesan moral didalamnya meskipun sangat aneh dan bisa saja sulit untuk dimengerti atau dipahami dengan sekali atau sekilas melihatnya. '''),
  Art(
      urlImage:
      "https://i0.wp.com/lh5.googleusercontent.com/proxy/H-BeJMYeWAS1Rw2JPCyGsRYnwsT8IKZzZJZOiy10bJKINd83eo5wvNd-bAWavK9eUxYsnsn4NOXhPnw2whFmygKS1I4MUr_Nv7lZk1FeJxQkG_6eohSFOJPfvKhR6YLNecgJlglc1e0paD2hdNkyk2ow70Ah_y0v1wQCIvtJ2gC9BAf1X-pVUxKbhQ=w1200-h630-p-k-no-nu?resize=650,400",
      name: "Lukisan Ekspresionisme",
      desc:
      '''Lukisan Ekspresionisme adalah aliran seni rupa yang menganggap bahwa seni merupakan sesuatu yang keluar dari diri seniman, bukan dari peniruan alam dunia. Seniman memiliki ingatan dan cara pandang tersendiri dari apa yang pernah dilihatnya di alam, lalu diekspresikan pada karyanya. Seniman ekspresionis menghiraukan berbagai teknik penciptaan formal untuk mendapatkan ekspresi yang lebih murni dan tanpa tekanan dari kepentingan ekstrinsik Seni. Singkatnya dapat dikatakan bahwa Ekspresionisme adalah aliran seni rupa yang menonjolkan ungkapan dari dalam jiwa.Meskipun begitu, biasanya seorang ekspresionis tetap memiliki kemampuan teknis yang hebat dan sensitibilitas tinggi terhadap issue-issue seni. Baik secara langsung seperti mempelajarinya sendiri, maupun secara tidak langsung yang erarti terpengaruh dari lingkungannya yang kaya akan khazanah seni. Hanya saja aliran ini memang menentang teknik-teknik yang telah mapan sebelumnya dan memilih untuk menggunakan formulanya sendiri, gejala yang biasa terjadi dalam proses perkembangan seni.'''),
  Art(
      urlImage:
      "https://asset.kompas.com/crops/z7malR5nmJ5sgvFZOqdtmSx_CM0=/0x46:757x551/750x500/data/photo/2022/06/08/62a0196d3bff7.jpg",
      name: "Lukisan Impresionisme",
      desc:
      '''Lukisan Impresionisme adalah salah satu aliran yang ada di dalam seni lukis yang cenderung berupaya untuk menonjolkan kekuatan pencahayaan dengan cara memainkan warna-warnanya. Selain itu, impresionisme juga lebih fokus pada pencahayaan yang terang, misalnya saja digambarkan suasana di pagi hari atau siang hari. Akan tetapi, aliran Impresionisme cenderung kurang dalam memperhatikan bentuk objeknya. Dimana bentuk yang ada di dalam aliran Impresionisme tidak digambarkan dengan jelas. Walaupun begitu, aliran impresionisme masih bisa menarik penikmat seni dengan kekuatan pencahayaan dan juga sapuan warna yang terang. Umumnya, pelukis yang beraliran Impresionisme memakai teknik melukis dengan kuas yang tebal dan pendek. Sehingga di dalam lukisannya akan memberikan kesan yang lebih mempermudah pelukis dan juga penikmat seni dalam menebak sebuat bentuk dan juga objek yang ada di lukisan. Para seniman Impresionisme sangat menentang untuk menggunakan warna yang gelap, khususnya hitam sebagai pewarnaan bayangan, karena warna hitam bukan menjadi warna khas dari aliran Impresionisme.  '''),
  Art(
      urlImage:
      "https://blog-static.mamikos.com/wp-content/uploads/2023/10/Contoh-Lukisan-Kubisme-beserta-Nama-Pelukisnya-Lengkap-dengan-Ciri-cirinya.jpg",
      name: "Lukisan Kubisme",
      desc:
      '''Aliran Kubisme merupakan salah satu seni rupa yang mempunyai sudut pandang dari suatu objek yang ada di dalam satu gambar. Sehingga akan menghasilkan gambar yang seolah-olah terpisah atau terfragmentasi. Fragmentasi yang ada di dalam aliran Kubisme akan membentuk suatu geometris seperti halnya kubus, segitiga, silinder, lingkaran, dan lainnya. Dengan begitu, aliran Kubisme tidak harus berbentuk kubus, namun juga bisa berbentuk geometris. Sebuah lukisan dari aliran Kubisme mempunyai sudut pandang depan dan samping yang bisa dilihat secara bersamaan dalam satu objek lukisan. Sehingga hal itu akan menghasilkan nilai yang artistik.''')
];