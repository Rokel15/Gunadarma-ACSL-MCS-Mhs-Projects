import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:projectawal/models/art.dart';

class DetailPage extends StatefulWidget {
  const DetailPage({Key? key, required this.art}) : super(key: key);
  final Art art;

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.art.name),
      ),
      body: Material(
        child: ListView(
          children: [
            Image.network(widget.art.urlImage),
            Container(
              child: Padding(
                padding: const EdgeInsets.only(top: 20, left: 15, right: 15),
                child: Text(
                  widget.art.desc,
                  style: GoogleFonts.oldenburg(
                      textStyle: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w500)),
                  textAlign: TextAlign.justify,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}