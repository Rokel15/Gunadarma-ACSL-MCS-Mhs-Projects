import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:projectawal/data/arts_data.dart';
import 'package:projectawal/models/art.dart';
import 'package:projectawal/screens/detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Project Lukisan',
          style: GoogleFonts.oldenburg(),
        ),
      ),
      body: Padding(
        padding:
        const EdgeInsets.only(top: 20, left: 15, right: 15, bottom: 20),
        child: ListView(
          children: [
            Center(
              child: Text(
                'Galeri Lukisann',
                style: GoogleFonts.oldenburg(
                    textStyle: const TextStyle(
                        backgroundColor: const Color(0xFF392467),
                        fontSize: 20, fontWeight: FontWeight.w600)),
              ),
            ),
            ListView.builder(
              itemCount: arts.length,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                Art art = arts[index];
                return Padding(
                  padding: const EdgeInsets.only(top: 30),
                  child: InkWell(
                    child: SizedBox(
                      width: double.infinity,
                      child: Row(
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 4,
                            height: MediaQuery.of(context).size.width / 4,
                            child: Image.network(
                              art.urlImage,
                              fit: BoxFit.cover,
                            ),
                          ),
                          const SizedBox(
                            width: 30,
                          ),
                          Text(
                            art.name,
                            style: GoogleFonts.oldenburg(
                                textStyle: const TextStyle(
                                    backgroundColor: const Color(0xFF392467),
                                    fontSize: 16, fontWeight: FontWeight.w600)),
                          )
                        ],
                      ),
                    ),
                    onTap: () {
                      Get.to(DetailPage(
                        art: art,
                      ));
                    },
                  ),
                );
              },
            )
          ],
        ),
      ),
    );
  }
}



