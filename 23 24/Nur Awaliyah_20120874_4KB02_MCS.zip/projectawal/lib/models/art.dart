class Art {
  String urlImage;
  String name;
  String desc;

  Art({
    required this.urlImage,
    required this.name,
    required this.desc,
  });
}