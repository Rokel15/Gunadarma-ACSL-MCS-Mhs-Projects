import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:projectawal/screens/home_page.dart';

void main() {
  runApp(const ArtPaintingApp());
}

class ArtPaintingApp extends StatelessWidget {
  const ArtPaintingApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Art Painting',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: const ColorScheme.dark()),
      home: const HomePage(),
    );
  }
}