part of 'art_bloc.dart';

@immutable
abstract class ArtEvent {}