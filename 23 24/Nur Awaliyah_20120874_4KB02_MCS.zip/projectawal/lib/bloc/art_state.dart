part of 'art_bloc.dart';

@immutable
abstract class ArtState {}

class ArtInitial extends ArtState {}

class ArtLoading extends ArtState {}

class ArtLoaded extends ArtState {}