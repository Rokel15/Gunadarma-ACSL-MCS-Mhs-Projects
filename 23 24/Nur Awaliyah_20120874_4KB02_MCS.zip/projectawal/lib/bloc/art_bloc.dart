import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

part 'art_event.dart';
part 'art_state.dart';

class ArtBloc extends Bloc<ArtEvent, ArtState> {
  ArtBloc() : super(ArtInitial()) {
    on<ArtEvent>((event, emit) {
      // TODO: implement event handler
    });
  }
}