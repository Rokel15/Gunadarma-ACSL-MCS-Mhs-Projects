package com.rinoindramcs.rinoindramcs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
