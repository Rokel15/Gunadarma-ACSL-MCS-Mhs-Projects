import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'PlayerPage.dart';
import 'ProfilePage.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawerEnableOpenDragGesture: false,
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Rino Indra Games',
              style: GoogleFonts.aladin(
                fontSize: 32,
                color: const Color(0xFF4CB9E7),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF392467),
      ),
      body: Container(
        color: const Color(0xFF4CB9E7),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Card(
                shadowColor: const Color.fromARGB(248, 70, 2, 80),
                elevation: 10,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(32)),
                color: const Color(0xFF392467),
                child: const SizedBox(
                  width: 360,
                  height: 60,
                  child: Center(
                    child: Text(
                      'Welcome to my Tic Tac Toe Games',
                      style: TextStyle(
                        fontSize: 20,
                        color: Color(0xFFFFFFFF),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Card(
                clipBehavior: Clip.antiAlias,
                shadowColor: const Color.fromARGB(248, 70, 2, 80),
                elevation: 50,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(32)),
                color: const Color.fromARGB(181, 41, 107, 127),
                child: const SizedBox(
                  width: 290,
                  height: 290,
                  child: Image(
                    image: AssetImage('assets/tic.png'),
                  ),
                ),
              ),
              const SizedBox(
                height: 30,
              ),
              const SizedBox(width: 50, height: 15),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  shadowColor: const Color.fromARGB(232, 3, 113, 82),
                  elevation: 20,
                  backgroundColor: const Color(0xFF392467),
                  minimumSize: const Size(225, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const PlayerPage()),
                  );
                },
                child: const Text(
                  'Ready To Play',
                  style: TextStyle(fontSize: 24),
                ),
              )
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ProfilePage()),
          );
        },
        backgroundColor: const Color(0xFF392467),
        child: const Icon(Icons.person),
      ),
    );
  }
}
