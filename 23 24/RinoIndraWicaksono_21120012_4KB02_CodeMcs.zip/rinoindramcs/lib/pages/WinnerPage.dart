import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class WinnerPage extends StatefulWidget {
  final String winner;

  const WinnerPage({Key? key, required this.winner}) : super(key: key);

  @override
  _WinnerPageState createState() => _WinnerPageState();
}

class _WinnerPageState extends State<WinnerPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Congratss',
                style: GoogleFonts.aladin(
                  fontSize: 32,
                  color: const Color(0xFF4CB9E7),
                ),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF392467),
        ),
        body: Container(
          color: const Color(0xFF4CB9E7),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '${widget.winner} wins!',
                  style: const TextStyle(fontSize: 50),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text(
                    'Play Again',
                    style: TextStyle(fontSize: 30),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
