import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'About Me',
              style: GoogleFonts.aladin(
                fontSize: 32,
                color: const Color(0xFF4CB9E7),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF392467),
      ),
      body: Container(
        color: const Color(0xFF4CB9E7),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipOval(
                child: SizedBox(
                  width: 360,
                  height: 360,
                  child: Image.asset(
                    'assets/rino.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Rino Indra Wicaksono',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF392467),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '4KB02',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF392467),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                '21120012',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF392467),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
