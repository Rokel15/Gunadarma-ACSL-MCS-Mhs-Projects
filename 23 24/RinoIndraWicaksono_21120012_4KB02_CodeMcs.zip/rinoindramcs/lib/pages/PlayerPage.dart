import 'package:flutter/material.dart';
import 'package:rinoindramcs/pages/BoardPage.dart';
import 'package:google_fonts/google_fonts.dart';

class PlayerPage extends StatefulWidget {
  const PlayerPage({Key? key}) : super(key: key);

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  final TextEditingController _firstPlayerController = TextEditingController();
  String firstPlayerName = '';

  void _onNextButtonPressed(BuildContext context) {
    setState(() {
      firstPlayerName = _firstPlayerController.text;
    });
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BoardPage(player: firstPlayerName),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Ready?',
                style: GoogleFonts.aladin(
                  fontSize: 32,
                  color: const Color(0xFF4CB9E7),
                ),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF392467),
        ),
        body: Container(
          color: const Color(0xFF4CB9E7),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: TextField(
                    controller: _firstPlayerController,
                    style: const TextStyle(fontSize: 20),
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'player',
                      hintText: 'Enter Your Name',
                    ),
                  ),
                ),
                const SizedBox(width: 50, height: 10),
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(const Color(0xFF392467)),
                  ),
                  onPressed: () {
                    _onNextButtonPressed(context);
                  },
                  child: const Text(
                    'Next',
                    style: TextStyle(fontSize: 40),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
