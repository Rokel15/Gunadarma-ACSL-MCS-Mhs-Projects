import 'package:flutter/material.dart';
import 'package:rinoindramcs/pages/SplashScreen.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: SplashScreen(),
  ));
}
