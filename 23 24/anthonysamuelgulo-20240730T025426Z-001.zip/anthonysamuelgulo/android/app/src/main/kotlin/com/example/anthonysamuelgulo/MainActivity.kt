package com.example.anthonysamuelgulo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
