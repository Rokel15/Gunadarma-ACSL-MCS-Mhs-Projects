import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:anthonysamuelgulo/screen/HomePage.dart';

import 'bloc/bloc_jaringan.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => JaringanBloc()..add(OnJaringanEvent()),
      child: GetMaterialApp(
        title: 'Jenis - jenis Komponen Jaringan',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorScheme: const ColorScheme.dark()),
        home: const HomePage(),
      ),
    );
  }
}