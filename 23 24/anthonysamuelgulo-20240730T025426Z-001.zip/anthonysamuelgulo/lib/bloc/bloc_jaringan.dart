import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import 'package:anthonysamuelgulo/data/jaringandata.dart';
import 'package:anthonysamuelgulo/model/model_jaringan.dart';

part 'event_jaringan.dart';
part 'state_jaringan.dart';

class JaringanBloc extends Bloc<JaringanEvent, JaringanState> {
  JaringanBloc() : super(JaringanInitial()) {
    on<OnJaringanEvent>((event, emit) async {
      emit(JaringanLoading());
      await Future.delayed(Duration(seconds: 5));
      emit(JaringanLoaded(model));
    });
  }
}
