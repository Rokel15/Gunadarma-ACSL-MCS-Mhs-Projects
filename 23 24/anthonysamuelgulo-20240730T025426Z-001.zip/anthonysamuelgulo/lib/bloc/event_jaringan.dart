part of 'bloc_jaringan.dart';

@immutable
abstract class JaringanEvent {}

class OnJaringanEvent extends JaringanEvent {}