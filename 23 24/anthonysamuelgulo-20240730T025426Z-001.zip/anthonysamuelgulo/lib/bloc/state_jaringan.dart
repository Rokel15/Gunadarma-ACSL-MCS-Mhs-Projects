part of 'bloc_jaringan.dart';

@immutable
abstract class JaringanState {}

class JaringanInitial extends JaringanState {}

class JaringanLoading extends JaringanState {}

class JaringanLoaded extends JaringanState {
  final List<JaringanL> result;

  JaringanLoaded(this.result);
}