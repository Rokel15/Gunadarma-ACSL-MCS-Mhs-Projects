import 'package:anthonysamuelgulo/model/model_jaringan.dart';

List<JaringanL> model = [
  JaringanL(
    images: "images/bridge.jpg",
    name: "Bridge",
    desc:
    ''' Bridge adalah sebuah piranti yang digunakan untuk meneruskan lalu lintas antara segmen jaringan berdasarkan informasi pada sebuah data link. Bridge juga memiliki fungsi untuk membagi jaringan yang besar menjadi beberapa jaringan kecil....''',
  ),JaringanL(
    images: "images/Hub dan switchjpg.jpg",
    name: "Hub dan Switch",
    desc:
    ''' Switch merupakan perangkat jaringan komputer yang berfungsi untuk menghubungkan beberapa komputer. Secara fisik, bentuk dari switch sama dengan hub, namun jika dilihat dari sisi logika switch sama dengan bridge. Switch memiliki dua tipe, yaitu unmanaged switch yang merupakan tipe termurah. Dan managed switch yang merupakan tipe termahal..''',
  ),JaringanL(
    images: "images/KabelJaringan.jpg",
    name: "Kabel jaringan",
    desc:
    ''' Kabel merupakan media untuk menghubungkan satu perangkat dengan perangkat yang lain. Terdapat beberapa jenis kabel untuk pembuatan saluran jaringan. Diantaranya adalah kabel coaxial, fiber optic, dan twisted pair..''',
  ),JaringanL(
    images: "images/modem.jpg",
    name: "Modem",
    desc:
    ''' Modem merupakan perangkat yang digunakan untuk menghubungkan antara perangkat komputer, dengan penyedia layanan internet atau disebut juga dengan Internet Service Provider (ISP)..''',
  ), JaringanL(
    images: "images/Peralatanjaringan.jpg",
    name: "NIC (Network Interface Card)",
    desc:
    ''' NIC dapat disebut juga dengan LAN Card Expansion Board yang digunakan supaya komputer dapat terhubung dengan jaringan. Ethernet terbagi menjadi empat jenis, yaitu ethernet (10 Mbit/detik), fast ethernet (100 Mbit/detik), gigabit ethernet (1000 Mbit/detik), dan tengig (10000 Mbit/detik)..''',
  ), JaringanL(
    images: "images/Peralatanjaringan_Server.jpg",
    name: "Server",
    desc:
    ''' Server berfungsi sebagai tempat atau media untuk menyimpan informasi, serta mengelola jaringan komputer. Server memiliki spesifikasi yang lebih tinggi dari client. Karena tujuan dari dibuatnya server memang untuk melayani komputer client..''',
  ), JaringanL(
    images: "images/repeater.jpg",
    name: "Repeater",
    desc:
    ''' Repeater adalah suatu perangkat yang berfungsi untuk memperkuat dan meregenerasi jaringan dan sinyal yang masuk. Repeater berusaha untuk mempertahankan integritas dari sinyal jaringan. Kelemahan dari repeater sendiri adalah tidak dapat melakukan filter traffic dalam jaringan..''',
  ), JaringanL(
    images: "images/router.jpg",
    name: "Router",
    desc:
    ''' Router adalah perangkat jarkom yang berfungsi untuk menghubungkan jaringan LAN ke dalam suatu jaringan WAN, serta mengelola lalu lintas dari data di dalamnya. Router dapat menentukan jalur terbaik, karena memiliki tabel routing untuk melakukan pencatatan terhadap semua alamat dalam jaringan..''',
  ),
];
