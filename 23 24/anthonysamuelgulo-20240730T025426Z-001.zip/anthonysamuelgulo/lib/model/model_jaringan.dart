class JaringanL {
  String images;
  String name;
  String desc;

  JaringanL ({
    required this.images,
    required this.name,
    required this.desc,
  });
}