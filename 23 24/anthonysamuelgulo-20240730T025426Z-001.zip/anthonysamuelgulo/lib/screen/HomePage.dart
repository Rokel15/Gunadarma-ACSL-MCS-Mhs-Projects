import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';


import 'package:anthonysamuelgulo/bloc/bloc_jaringan.dart';
import 'DetailPage.dart';
import 'ProfilePage.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Jenis - Jenis Komponens Jaringan',
              style: GoogleFonts.adamina(
                fontSize: 32,
                color: const Color(0xFF49108B),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFFF3F8FF),
      ),
      body: Container(
        color: const Color(0xFFF3F8FF),
        child: BlocBuilder<JaringanBloc, JaringanState>(
          builder: (context, state) {
            if (state is JaringanLoading) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (state is JaringanLoaded) {
              final model = state.result;

              return Padding(
                padding: const EdgeInsets.all(10),
                child: ListView(
                  children: [
                    ListView.builder(
                      itemCount: model.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        final hero = model[index];
                        return InkWell(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 20),
                            child: SizedBox(
                              width: double.infinity,
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  Container(
                                    child: Image.network(
                                      hero.images,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    color: Colors.black.withOpacity(0.5),
                                    child: Text(
                                      hero.name,
                                      style: const TextStyle(
                                        fontSize: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          onTap: () {
                            Get.to(DetailPage(models: hero));
                          },
                        );
                      },
                    ),
                  ],
                ),
              );
            }
            return Container();
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(const ProfilePage());
        },
        backgroundColor: const Color(0xFFF3F8FF),
        child: const Icon(Icons.person_2_outlined),
      ),
    );
  }
}
