import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:anthonysamuelgulo/model/model_jaringan.dart';

class DetailPage extends StatefulWidget {
  JaringanL models;

  DetailPage({super.key, required this.models});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.models.name,
          style: GoogleFonts.adamina(
            fontSize: 32,
            color: const Color(0xFF49108B),
          ),
        ),
        backgroundColor: const Color(0xFFF3F8FF),
      ),
      body: Container(
        color: const Color(0xFFF3F8FF),
        child: ListView(
          shrinkWrap: true,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Image.network(
                    widget.models.images,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding:
                  const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10, // Adjust as needed
                      ),
                      Text(
                        widget.models.name,
                        style: GoogleFonts.roboto(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF49108B),
                        ),
                        textAlign: TextAlign.justify,
                      ),
                      const SizedBox(
                        height: 10, // Adjust as needed
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding:
                  const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Text(
                    widget.models.desc,
                    style: GoogleFonts.roboto(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF49108B),
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ),
                const SizedBox(height: 150),
              ],
            )
          ],
        ),
      ),
    );
  }
}
