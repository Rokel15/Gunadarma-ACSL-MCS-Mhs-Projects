import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'About Me',
              style: GoogleFonts.adamina(
                fontSize: 32,
                color: const Color(0xFF49108B),
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFFF3F8FF),
      ),
      body: Container(
        color: const Color(0xFFF3F8FF),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipOval(
                child: SizedBox(
                  width: 380,
                  height: 380,
                  child: Image.asset(
                    'images/Samuel.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Anthony Samuel Gulo',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF49108B),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                '4KB03',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF49108B),
                ),
              ),
              const SizedBox(height: 15),
              const Text(
                '20120170',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF49108B),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
