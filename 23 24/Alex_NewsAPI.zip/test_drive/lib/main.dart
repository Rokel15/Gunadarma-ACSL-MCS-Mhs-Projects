import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'NewsPage.dart';

void main(){
  runApp(newsApp());
}

class newsApp extends StatelessWidget {
  const newsApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: "Today's News",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.light(),
      ),
      home: NewsPage(),
    );
  }
}


