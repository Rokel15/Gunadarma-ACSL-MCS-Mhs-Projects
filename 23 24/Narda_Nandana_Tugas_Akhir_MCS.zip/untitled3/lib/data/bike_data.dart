import '../model/bike.dart';

List<bike> cars = [

  bike(
      urlImage:
       "https://imgcdn.oto.com/medium/gallery/exterior/73/987/honda-vario-125-esp-58477.jpg",
      name: "Vario",
      place: "Rp. 23.000.000",
      desc:
      ''' Honda Vario 125 tersedia dalam pilihan mesin Petrol di Indonesia Scooter baru dari Honda hadir dalam 6 varian. Bicara soal spesifikasi mesin Honda Vario 125, ini ditenagai dua pilihan mesin Petrol berkapasitas 124.8 cc. Vario 125 tersedia dengan transmisi CVT tergantung variannya. Vario 125 adalah Scooter 2 seater dengan panjang 1918 mm, lebar 679 mm, wheelbase 1280 mm. serta ground clearance 131 mm.'''),
  bike(
      urlImage:
       "https://akcdn.detik.net.id/community/media/visual/2023/02/01/honda-beat-2023-2_169.jpeg?w=700&q=90",
      name: "Beat",
      place: "Rp. 17.000.000",
      desc:
      '''Honda Beat tersedia dalam pilihan mesin Petrol di Indonesia Scooter baru dari Honda hadir dalam 6 varian. Bicara soal spesifikasi mesin Honda Beat, ini ditenagai dua pilihan mesin Petrol berkapasitas 110 cc. Beat tersedia dengan transmisi CVT tergantung variannya. Beat adalah Scooter 2 seater dengan panjang 1877 mm, lebar 669 mm, wheelbase 1256 mm. serta ground clearance 147 mm.'''),
  bike(
      urlImage:
      "https://akcdn.detik.net.id/community/media/visual/2023/03/01/yamaha-aerox-2023-thailand-1_169.jpeg?w=700&q=90",
      name: "Aerox",
      place: "Rp. 28.000.000",
      desc:
      '''Yamaha Aerox Connected tersedia dalam pilihan mesin Petrol di Indonesia Scooter baru dari Yamaha hadir dalam 4 varian. Bicara soal spesifikasi mesin Yamaha Aerox Connected, ini ditenagai dua pilihan mesin Petrol berkapasitas 155 cc. Aerox Connected tersedia dengan transmisi CVT tergantung variannya. Aerox Connected adalah Scooter 2 seater dengan panjang 1980 mm, lebar 700 mm, wheelbase 1350 mm. serta ground clearance 143 mm.'''),
  bike(
      urlImage:
      "https://www.hondacengkareng.com/wp-content/uploads/2018/11/Honda-PCX-160-CBS-Brilliant-Black-1.png",
      name: "PCX",
      place: "Rp. 33.000.000",
      desc:
      '''Honda PCX160 tersedia dalam pilihan mesin Petrol di Indonesia Scooter baru dari Honda hadir dalam 4 varian. Bicara soal spesifikasi mesin Honda PCX160, ini ditenagai dua pilihan mesin Petrol berkapasitas 156.9 cc. PCX160 tersedia dengan transmisi CVT tergantung variannya. PCX160 adalah Scooter 2 seater dengan panjang 1936 mm, lebar 742 mm, wheelbase 1313 mm. serta ground clearance 135 mm.'''),
];