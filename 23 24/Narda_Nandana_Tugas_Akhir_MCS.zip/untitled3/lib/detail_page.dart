import 'package:flutter/material.dart';

import '../model/bike.dart';


class DetailPage extends StatelessWidget {
  const DetailPage({super.key, required this.car});
  final bike car;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(car.name),

      ),
      body: Column(
        children: [Image.network(car.urlImage),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(car.desc,
              textAlign: TextAlign.justify,
            ),
          )
        ],
      ),
    );
  }
}