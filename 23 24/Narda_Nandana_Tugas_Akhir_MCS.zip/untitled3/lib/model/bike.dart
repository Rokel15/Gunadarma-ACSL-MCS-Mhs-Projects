// cats.dart

class bike {
  String urlImage;
  String name;
  String desc;
  String place;  // Tambahkan properti 'place' di sini

  bike ({
    required this.urlImage,
    required this.name,
    required this.desc,
    required this.place,
  });
}