package com.example.galerymoge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
