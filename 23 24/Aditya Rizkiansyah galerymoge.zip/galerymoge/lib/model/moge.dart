class Moge {
  final String urlImage;
  final String name;
  final String desc;
  final String Price;

  Moge({
    required this.urlImage,
    required this.name,
    required this.desc,
    required this.Price,
  });
}
