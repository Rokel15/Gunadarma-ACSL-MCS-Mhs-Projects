import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:galerymoge/model/moge.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:galerymoge/screen/detail_page.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/moge_bloc.dart';

class MogeOverviewScreen extends StatelessWidget {
  const MogeOverviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rental Moge'),
      ),
      body: BlocBuilder<MogeBloc, MogeState>(
        builder: (context, state) {
          if (state is MogeLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (state is MogeLoaded) {
            final moges = state.result;
            return ListView(
              children: [
                Center(
                  child: Text(
                    'Jenis-jenis Moge',
                    style: GoogleFonts.openSans(
                        textStyle: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w600)),
                  ),
                ),
                ListView.builder(
                  itemCount: moges.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    final moge = moges[index];
                    return Padding(
                      padding: const EdgeInsets.only(top: 30),
                      child: InkWell(
                        child: SizedBox(
                          width: double.infinity,
                          child: Row(
                            children: [
                              SizedBox(
                                width: MediaQuery.of(context).size.width / 4,
                                height: MediaQuery.of(context).size.width / 4,
                                child: Image.network(
                                  moge.urlImage,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              const SizedBox(
                                width: 30,
                              ),
                              Text(
                                moge.name,
                                style: GoogleFonts.openSans(
                                    textStyle: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600)),
                              )
                            ],
                          ),
                        ),
                        onTap: () {
                          Get.to(DetailPage(
                            moge: moge,
                          ));
                        },
                      ),
                    );
                  },
                )
              ],
            );
          }
          return Container();
        },
      ),
    );
  }
}