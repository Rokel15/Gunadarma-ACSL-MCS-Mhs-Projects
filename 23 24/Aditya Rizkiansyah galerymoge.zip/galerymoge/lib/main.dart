import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:galerymoge/screen/moge_overview_screen.dart';
import 'package:galerymoge/screen/home_page.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


import 'bloc/moge_bloc.dart';

void main() {
  runApp(const MogeBreedApp());
}

class MogeBreedApp extends StatelessWidget {
  const MogeBreedApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => MogeBloc()..add(OnMogeEventCalled()),
      child: GetMaterialApp(
        title: 'Moge Breed',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorScheme: const ColorScheme.dark()),
        home: const MogeOverviewScreen(),
      ),
    );
  }
}