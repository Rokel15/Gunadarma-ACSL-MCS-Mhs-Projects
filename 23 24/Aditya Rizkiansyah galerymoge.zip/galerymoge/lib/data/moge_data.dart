import '../model/moge.dart';

List<Moge> mogeData = [
  Moge(
      urlImage: "https://trackbikedecals.com/cdn/shop/products/World_Superbike_WSBK_style_headlight_decals_stickers_for_Honda_CBR1000RR_Fireblade_SP2_2017_1024x1024.jpg?v=1542725368",
      name: "Honda CBR 1000RR",
      desc: "Motor Mulus Terawat ( Full Modif )",
      Price: "5.000.000"),

  Moge(
      urlImage: "https://imgwebikenet-e00b.kxcdn.com/@wid-news/wp-content/uploads/2020/08/harga-review-aksesoris-modifikasi-honda-crf1000l-africa-twin-webike-indonesia.png",
      name: "Honda CRF1000L African Twin ",
      desc: "Motor Mulus Terawat ( Full Modif Trabas )",
      Price: "4.000.000"),

  Moge(
      urlImage: "https://i0.wp.com/pertamax7.sgp1.cdn.digitaloceanspaces.com/wp-content/uploads/2016/04/Modifikasi-Honda-CBR500R-2016-pertamax7.com-.jpg?ssl=1",
      name: "Honda CBR500R",
      desc: "Motor Mulus Terawat ( Full Modif )",
      Price: "1,500,000"),

  Moge(
      urlImage: "https://www.hondacengkareng.com/wp-content/uploads/2017/05/honda-rebel-cmx500.jpg",
      name: "Honda Rebel CMX 500",
      desc: "Motor Mulus Terawat ( Original )",
      Price: "1,000,000"),

  Moge(
      urlImage: "https://awsimages.detik.net.id/community/media/visual/2023/01/30/honda-cb500f_169.jpeg?w=1200",
      name: "Honda CB500F",
      desc: "Motor Mulus Terawat ( Original )",
      Price: "1,000,000"),

  Moge(
      urlImage: "https://baogiaothong.mediacdn.vn/upload/images/2021-3/album_img/2021-07-15/img-bgt-2021-cb1000r-6-1626286349-width1004height565.jpg",
      name: "Honda CB1000R",
      desc: "Motor Mulus Terawat ( Full Modif )",
      Price: "5.000.000"),

  Moge(
      urlImage: "https://naikmotor.com/wp-content/uploads/2019/11/336890_CB650R_FOUR_Limited_Edition_by_Espace_Motos_France.jpg",
      name: "Honda CB650R neo sport cafe",
      desc: "Motor Mulus Terawat ( Full Modif )",
      Price: "3.500.000"),
];
  