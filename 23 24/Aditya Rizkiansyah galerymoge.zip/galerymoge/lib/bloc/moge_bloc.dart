import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../data/moge_data.dart';
import '../model/moge.dart';

part 'moge_event.dart';
part 'moge_state.dart';

class MogeBloc extends Bloc<MogeEvent, MogeState> {
  MogeBloc() : super(MogeInitial()) {
    on<OnMogeEventCalled>((event, emit) async {
      emit(MogeLoading());
      await Future.delayed(const Duration(seconds: 2));
      emit(MogeLoaded(mogeData));
    });
  }
}