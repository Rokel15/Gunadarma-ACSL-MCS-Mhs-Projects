part of 'moge_bloc.dart';

@immutable
sealed class MogeEvent {}
class OnMogeEventCalled extends MogeEvent {}