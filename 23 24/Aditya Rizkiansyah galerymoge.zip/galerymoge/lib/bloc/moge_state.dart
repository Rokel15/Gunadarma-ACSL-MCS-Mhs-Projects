part of 'moge_bloc.dart';

@immutable
sealed class MogeState {}

final class MogeInitial extends MogeState {}

final class MogeLoading extends MogeState {}

final class MogeLoaded extends MogeState {
  final List<Moge> result;

  MogeLoaded(this.result);
}