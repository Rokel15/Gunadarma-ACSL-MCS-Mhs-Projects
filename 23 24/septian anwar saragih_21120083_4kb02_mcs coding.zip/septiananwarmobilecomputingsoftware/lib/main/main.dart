import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:septiananwarmobilecomputingsoftware/pages/MainPage.dart';
import 'package:septiananwarmobilecomputingsoftware/pages/SplashPage.dart';

import '../bloc/valo_bloc.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ValoBloc()..add(OnValoEvent()),
      child: GetMaterialApp(
        title: 'Valorant',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorScheme: const ColorScheme.dark()),
        home: const SplashPage(),
      ),
    );
  }
}
