import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:meta/meta.dart';

import '../data/valorantdatamodel.dart';
import '../model/valo.dart';

part 'valo_event.dart';
part 'valo_state.dart';

class ValoBloc extends Bloc<ValoEvent, ValoState> {
  ValoBloc() : super(ValoInitial()) {
    on<OnValoEvent>((event, emit) async {
      emit(ValoLoading());
      await Future.delayed(const Duration(seconds: 5));
      emit(ValoLoaded(valorant));
    });
  }
}
