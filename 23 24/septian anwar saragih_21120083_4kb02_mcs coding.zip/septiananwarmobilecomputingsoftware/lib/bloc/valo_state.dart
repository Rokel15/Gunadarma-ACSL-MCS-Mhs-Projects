part of 'valo_bloc.dart';

@immutable
abstract class ValoState {}

class ValoInitial extends ValoState {}

class ValoLoading extends ValoState {}

class ValoLoaded extends ValoState {
  final List<Valo> result;

  ValoLoaded(this.result);
}
