part of 'valo_bloc.dart';

@immutable
abstract class ValoEvent {}

class OnValoEvent extends ValoEvent {}