class Valo {
  String name;
  String desc;
  String imageHero;
  String skill;

  Valo ({
    required this.name,
    required this.desc,
    required this.imageHero,
    required this.skill,
  });
}
