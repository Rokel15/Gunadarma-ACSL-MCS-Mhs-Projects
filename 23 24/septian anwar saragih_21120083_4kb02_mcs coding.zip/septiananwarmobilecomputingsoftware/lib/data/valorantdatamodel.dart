import '../model/valo.dart';

List<Valo> valorant = [
  Valo(
      name: "Sage",
      desc:
          '''Sage merupakan seorang agent yang berasal dari Tiongkok. Hero ini bisa sangat berguna dalam pertarungan karena ia bisa menjaga dirinya dan bahkan membangkitkan teman yang sudah mati tertembak.''',
      imageHero: "assets/sage.webp",
      skill: '''Jurus-jurus yang dimiliki Sage:

Slow orb: Sage bisa melemparkan sebuah orbs yang nantinya akan pecah dan memperlambat pergerakan musuh.

Healing orb: Dengan jurus ini Sage bisa menyembuhkan musuh ataupun diri sendiri.

Barier orb: Sage bisa menciptakan semacam tembok yang akan hancur bila ditembaki terus-menerus.

Resurrection: Dengan jurus pamungkas ini, Sage bisa menghidupkan kembali teman dengan kondisi full HP.'''),
  Valo(
      name: "Viper",
      desc:
          '''Ahli kimia dari Amerika Serikat ini bisa menyebarkan racun dan melumpuhkan penglihatan musuh. Selain itu, wanita yang identik dengan warna hijau ini pun bisa menjebak musuh dalam racunnya.''',
      imageHero: "assets/viper.webp",
      skill: '''Jurus-jurus yang dimiliki Viper: 

Poison cloud: Viper bisa melemparkan sebuah tabung berisi gas yang bisa menghalangi vision musuh. Menariknya, bila tabung tersebut diambil kamu bisa menggunakannya lagi.

Toxic screen: Dengan jurus ini Viper bisa menghadirkan semacam tembok untuk menghalangi pandangan musuh. Sama seperti Poison cloud, skill ini pun bisa dipakai berulang kali.

Snake bite: Viper bisa melemparkan cairan kimisa yang akan pecah dan bisa memperlambat pergerakan musuh.

Viper’s pit: Viper bisa menghasilkan semacam kubah dengan racunnya dan jika musuh berada di dalamnya akan berkurang HP-nya. Oh iya, jurus ini juga berguna untuk menghalangi penglihatan musuh.'''),
  Valo(
      name: "Jett",
      desc:
          '''Hero kedua dalam daftar agent Valorant dengan peran duelist adalah Jett. Berasal dari Korea Selatan, karakter ini hadir dengan elemen angin dan pisau sebagai senjata pamungkasnya. Kemampuannya untuk bergerak dengan cepat membuatnya jadi pembunuh yang andal.''',
      imageHero: "assets/jett.webp",
      skill: '''Jurus-jurus yang dimiliki Jett:
Updraft: Secara instan akan membuat Jett naik ke ketinggian.

Tailwind: Jurus ini akan mempercepat gerak Jett ke arah yang dipilih. Jika dalam keadaan diam, ia akan maju ke depan secara cepat.

Cloudburst: Dengan jurus ini Jett bisa menghalangi penglihatan musuh dengan sebuah bola angin besar. Blade storm: Seperti yang telah dijelaskan sebelumnya, Jett punya senjata pisau yang akan muncul pada skill ultimate-nya. Jurus ini bisa mematikan musuh dengan sangat cepat.'''),
  Valo(
      name: "Skye",
      desc:
      '''Berasal dari Australia, Skye bisa menjadi pembuka perang yang ciamik. Karena dengan kemampuannya ia bisa membuka area lawan dan bisa menyembuhkan teman juga. Oleh sebab itu, kamu akan menang bila di timmu ada Skye.''',
      imageHero: "assets/skye.webp",
      skill: '''Jurus-jurus yang dimiliki Skye:

Trailblazer: Skye bisa menyuruh perhiasan macan Tasmania-nya untuk maju dan menciptakan ledakan.

Guiding light: Skye bisa menciptakan sebuah Elang untuk mendeteksi musuh.

Regrowth: Dengan jurus ini Skye bisa meneymbuhkan musuh dalam jarak tertentu.

Seekers: Jurus pamungkas dari Skye ini bisa mendeteksi tiga musuh terdekat. Jika musuh terkena jurus ini, penglihatannya akan terbutakan dalam beberapa waktu.'''),
  Valo(
      name: "Phoenix",
      desc:
          '''Phoenix di Valorant dikisahkan sebagai seseorang yang berasal dari Inggris. Pada dasarnya karakter ini berelemen api, sehingga semua jurusnya punya kaitan dengan elemen tersebut. Hero yang satu ini sangat cocok untuk dijadikan rusher karena kemampuannya.''',
      imageHero: "assets/phoenix.webp",
      skill: '''Jurus-jurus yang dimiliki oleh Phoenix:

Curveball: Bisa menembakkan flare orb yang bisa membutakan musuh bila dalam jangakuan. Oh ya, jurus ini perlu diarahkan untuk bisa mendapatkan hasil yang sempurna.

Hot hands: Dengan jurus ini Phoenix akan menghadirkan bola api yang jika terlempar akan membuat tanah terbakar. Gunakan jurus ini untuk memperlambat pergerakan musuh.

Blaze: Dengan jurus ini Phoenix bisa membuat sebuah tembok api yang bisa menghalangi penglihatan dan memberikan damage saat musuh melewatinya. 

Run it back: Ini adalah jurus pamungkas dari Phoenix. Dengan skill ini kamu bisa bergerak ke lokasi lawan tanpa takut tertembak. Karena bila tertembak kamu akan kembali ke posisi awal saat mengaktifkan jurus tersebut dengan kondisi HP penuh.'''),
  Valo(
      name: "Reyna",
      desc:
          '''Agent yang satu ini dikisahkan berasal dari Meksiko. Kemampuannya bertarung jarak dekat membuatnya sangat dominan. Oleh karena itu, dalam pertarungan banyak tim yang mengandalkan Reyna sebagai pembunuh yang sangat ditakuti.''',
      imageHero: "assets/reyna.webp",
      skill: '''Jurus-jurus yang dimiliki Reyna:

Devour: Reyna bisa menyembuhkan dirinya setelah membunuh musuhnya dengan mengandalkan Soul Orb yang muncul.

Dismiss: Saat mengonsumsi Soul Orb, Reyna bisa menjadi tidak terlihat dalam durasi yang singkat. Jurus ini tetap berjalan meski Empress juga diaktifkan.

Leer: Jurus ini bisa menghadirkan mata berbentuk orbs ungu yang bisa dihancurkan. Namun, saat dilepaskan musuh akan mengalami gangguan penglihatan dalam waktu tertentu.

Empress: Skill ultimat ini akan meningkatkan kemampuan menembak, mengisi ulang peluru, hingga mengganti senjata. Bila membunuh dengan jurus ini, kamu bisa menggunakan Empress dengan durasi lebih panjang.'''),Valo(
      name: "Cypher",
      desc:
          '''Hadir sebagai karakter dari Maroko, Cypher merupakan seroang makelar informasi. Agent ini bisa memberikan jaringan pengawasan untuk membaca pergerakan dari musuh. Di mana pun dan kapan pun Cypher selalu akan mengintai.''',
      imageHero: "assets/cypher.webp",
      skill: '''Jurus-jurus yang dimiliki Cypher:

Cyber cage: Cypher bisa membuat semacam kandang cyber untuk menghalangi pandangan musuh serta memperlambat gerakannya.

Spycam: Sesuai namanya, dengan jurus ini Cypher bisa menempatkan kamera untuk memata-matai musuh.

Trapwire: Skill ini bisa membuat musuh terjebak dan pusing untuk beberapa saat.

Neutral theft: Jurus ultimat Cypher ini bisa digunakan untuk memindai musuh yang masih hidup dengan cara menggunakan mayat musuh yang sudah mati.'''),
  Valo(
      name: "Raze",
      desc:
          '''Karakter di Valorant yang ini dikisahkan sebagai gadis yang menyukai ledakan dan berasal dari Brasil. Mungkin dia adalah agent yang sangat mengandalkan jurusnya jika dibandingkan dengan duelist lainnya. Akan tetapi, Raze bisa diandalkan untuk bertarung dalam jarak yang dekat.''',
      imageHero: "assets/raze.webp",
      skill: '''Jurus-jurus yang dimiliki Raze:

Blast pack: Bisa melemparkan bom yang menempel ke mana saja. Raze tidak akan terkena damage bila bom ini meledak di dekatnya. Namun, jika karena ledakan ia jatuh, HP yang ia punya akan berkurang.

Paint shells: Raze bisa melepaskan sebuah cluster granade. Granat ini akan melukai siapapun saat meledak.

Boom bot: Raze akan melepaskan sebuah robot yang memiliki daya ledak. Robot ini bisa melihat dan mengunci musuh. Damage yang dihasilkan lumayan besar.

Showstopper: Jurus ultimate ini memungkinkan Raze untuk melontarkan sebuah roket. Siapa pun yang terkena akan terluka parah.'''),
  Valo(
      name: "Omen",
      desc:
          '''Karakter controller di Valorant berikutnya adalah Omen. Omen digambarkan sebagai sebuah hantu yang selalu berburu di dalam bayangan. Ia bisa melakukan teleport ke berbagai area sehingga gerak-geriknya tidak mudah untuk ditebak.''',
      imageHero: "assets/omen.webp",
      skill: '''Jurus-jurus yang dimiliki Omen:

Paranoia: Omen bisa membuat musuh menjadi buta dengan jurus ini. Menariknya skill ini bisa tembus tembok, lho. 

Dark cover: Jurus ini bisa membuat Omen untuk menghadirkan sebuah ruang untuk menghambat musuh dalam melihat. Oh iya, ruang tersebut bisa diletakkan di mana saja.

Shrouded step: Skill ini memungkinkan Omen untuk melakukan teleport.

From the shadows: Jurus pamungkas dari Omen ini mampu membuat kamu untuk melakukan teleport ke mana pun di dalam map. Akan tetapi, jurus ini bisa dihentikan oleh musuh untuk menggagalkan teleport-nya.'''),
  Valo(
      name: "Brimstone",
      desc:
          '''Karakter Valorant yang satu ini hadir sebagai tentara dari Amerika Serikat. Ia bisa mengontrol map dengan kemampuannya. Tidak hanya itu, adanya Brimstone di dalam tim akan memberikan keuntungan yang sangat besar saat pertarungan terjadi.''',
      imageHero: "assets/brimstone.webp",
      skill: '''Jurus-jurus yang dimiliki Brimstone:

Incendiary: Brimstone bisa melemparkan sebuah granat yang akan meledak dan membakar lantai. Siapapun yang melewatinya akan terkena damage.

Sky smoke: Skill ini berguna untuk menutupi penglihatan lawan dan bisa diatur dari mana saja.

Stim beacon: Adanya jurus ini memungkinkan kamu atau temanmu untuk melakukan tembakan beruntun di area yang sudah ditentukan.

Orbital strike: Jurus ulitmate yang dimiliki Brimstone ini bisa membuat sebuah area terkena orbital strike laser. Bila terkena damage-nya besar sekali.'''),
  Valo(
      name: "Breach",
      desc:
          '''Karakter initiator di Valorant yang pertama adalah Breach. Bionik asala Swedia ini punya tembakan yang sangat kuat dan bisa membuka jalan saat ingin memulai pertarungan. Apalagi damage yang dihasilkannya tidak main-main, sakit sekali.''',
      imageHero: "assets/breach.webp",
      skill: '''Jurus-jurus yang dimiliki Breach:

Flashpoint: Breach bisa menembakan senjatanya untuk memberikan efek buta pada musuh. Skill ini pun bisa menembus tembok.

Fault line: Breach bisa menghasilkan sebuah ledakan seismik yang akan mambuat musuh pusing bila terkenanya.

Aftershock: Dengan skill ini Breach bisa menghasilkan sebuah fusion charge. Jika musuh berada di dalam zona tersebut akan terkena damage yang besar.

Rolling thunder: Skill ultimate ini menghasilkan sebuah seismic charge yang akan membuat musuh pusing dan terlempar saat berada di dalam areanya.'''),
  Valo(
      name: "Sova",
      desc:
          '''Digambarkan berasal dari sebuah tundra di Rusia, Sova bisa jadi salah satu inisiator yang hebat. Ia bisa melakukan pelacakan hingga membunuh musuh dengan sangat efisien. Apalagi karakter ini memiliki senjata lain yaitu busur panah.''',
      imageHero: "assets/sova.webp",
      skill: '''Jurus-jurus yang dimiliki Sova:

Shock bolt: Sova bisa menembakan panah yang bisa meledak dan menghasilkan damage yang cukup untuk memperlambat musuh.

Recon bolt: Dengan skill ini Sova bisa membantu tim untuk mendeteksi lawan.

Owl drone: Sova bisa melepaskan drone untuk mengintai lokasi musuh.

Hunter’s fury: Jurus ultimate yang memungkinkan Sova untuk melepaskan tiga anak panah untuk menghasilkan damage yang cukup besar.  Oh iya, jrus ini juga bisa dipakai untuk mengidentifikasi musuh di area yang terhalang tembok.'''),
  Valo(
      name: "Killjoy",
      desc:
          '''Karakter ini digambarkan sebagai seorang yang jenius dan berasal dari Jerman. Ia bisa berperang dengan bermacam barang ciptaannya. Agent yang ini memiliki visual seorang wanita dengan tampilan geek dan memiliki jaket kuning yang cerah.''',
      imageHero: "assets/killjoy.webp",
      skill: '''Jurus-jurus yang dimiliki Killjoy:

Alarmbot: Killjoy bisa menempatkan sebuah robot yang bisa menembak musuh bila dalam jangkauan. Saat menembak dan musuhnya mendekat, robot tersebut akan meledak.

Turret: Skill ini memungkinkan Killjoy untuk membuat sebuah menara kecil yang bisa menembaki musuh dengan jangkauan sudut 180 derajat.

Nanoswarm: Killjoy akan melemparkan sebuah granat Nanoswarm. Bila musuh terkena atau dalam jangkauan zonanya bisa dipastikan akan mati.

Lockdown: Jurus ultimate dari Killjoy ini bisa menempatkan semacam alat lockdown. Begitu ditanamkan maka alat ini bisa menangkap semua musuh yang ada di dalam jangkauan. Akan tetapi, alat ini bisa dihancurkan oleh musuh.'''),
];
