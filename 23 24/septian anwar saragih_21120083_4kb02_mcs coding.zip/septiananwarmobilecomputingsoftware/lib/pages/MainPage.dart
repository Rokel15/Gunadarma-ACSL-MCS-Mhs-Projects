import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:septiananwarmobilecomputingsoftware/bloc/valo_bloc.dart';

import 'DetailPage.dart';
import 'ProfilePage.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _HomePageState();
}

class _HomePageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Valorant',
              style: GoogleFonts.cinzel(
                fontSize: 32,
                color: const Color(0xFFFFFFFF),
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFFFF4655),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle), // Ikon profil (ganti sesuai kebutuhan)
            onPressed: () {
              Get.to(const ProfilePage());
              // Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
            },
            iconSize: 40.0,
          ),
        ],
      ),
      body: Container(
        color: const Color(0xFFFF4655),
        child: BlocBuilder<ValoBloc, ValoState>(
          builder: (context, state) {
            if (state is ValoLoading) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (state is ValoLoaded) {
              final valorant = state.result;

              return Padding(
                padding: const EdgeInsets.all(10),
                child: ListView(
                  children: [
                    ListView.builder(
                      itemCount: valorant.length,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        final valorantHeroes = valorant[index];
                        return InkWell(
                          child: Padding(
                            padding: const EdgeInsets.only(bottom: 20),
                            child: SizedBox(
                              width: double.infinity,
                              child: Stack(
                                alignment: Alignment.bottomCenter,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(35.0), // Radius border untuk gambar
                                    child: Image.network(
                                      valorantHeroes.imageHero,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    color: Colors.white.withOpacity(0.2),
                                    child: Text(
                                      valorantHeroes.name,
                                      style: GoogleFonts.cinzel(
                                        fontSize: 22,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          onTap: () {
                            Get.to(DetailPage(valo: valorantHeroes));
                          },
                        );
                      },
                    ),
                  ],
                ),
              );
            }
            return Container();
          },
        ),
      ),
    );
  }
}
