import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../model/valo.dart';

class DetailPage extends StatefulWidget {
  Valo valo;

  DetailPage({super.key, required this.valo});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          widget.valo.name,
          style: GoogleFonts.cinzel(
            fontSize: 32,
            color: const Color(0xFFFFFFFF),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF0D1824),
      ),
      body: Container(
        color: const Color(0xFF0D1824),
        child: ListView(
          shrinkWrap: true,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Image.network(
                    widget.valo.imageHero,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10, // Adjust as needed
                      ),
                      Text(
                        widget.valo.name,
                        style: GoogleFonts.cinzel(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFFFFFFFF),
                        ),
                        textAlign: TextAlign.justify,
                      ),
                      const SizedBox(
                        height: 10, // Adjust as needed
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Text(
                    widget.valo.desc,
                    style: GoogleFonts.cinzel(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFFFF4655),
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ),Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Text(
                    widget.valo.skill,
                    style: GoogleFonts.cinzel(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFFFF4655),
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ),
                const SizedBox(height: 150),
              ],
            )
          ],
        ),
      ),
    );
  }
}
