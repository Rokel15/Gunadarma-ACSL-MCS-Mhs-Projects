class mikon {
  String urlImage;
  String name;
  String desc;

  mikon({
    required this.urlImage,
    required this.name,
    required this.desc,
  });
}